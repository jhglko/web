$(function() {
    "use strict";
})