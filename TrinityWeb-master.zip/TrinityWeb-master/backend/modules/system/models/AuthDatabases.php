<?php

namespace backend\modules\system\models;

use core\modules\installer\models\setup\DatabaseForm;

class AuthDatabases extends DatabaseForm
{
}
