<?php

namespace backend\modules\system\controllers;

use Yii;
use yii\caching\Cache;
use yii\caching\TagDependency;
use yii\data\ArrayDataProvider;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\HttpException;

/**
 * Class CacheController
 *
 * @package backend\controllers
 */
class CacheController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    [
                        'allow'       => true,
                        'permissions' => [
                            Yii::$app->PermissionHelper::ACCESS_BACKEND_TO_CACHE
                        ]
                    ]
                ]
            ]
        ];
    }

    /**
     * @return string
     */
    public function actionIndex()
    {
        $dataProvider = new ArrayDataProvider(['allModels' => $this->findCaches()]);

        return $this->render('index', ['dataProvider' => $dataProvider]);
    }

    /**
     * @param $id
     *
     * @throws HttpException
     * @return \yii\web\Response
     */
    public function actionFlushCache($id)
    {
        if ($this->getCache($id)->flush()) {
            Yii::$app->session->setFlash('alert', [
                'body'    => \Yii::t('backend', 'Cache has been successfully flushed'),
                'options' => ['class' => 'alert-success'],
            ]);
        };

        return $this->redirect(['index']);
    }

    /**
     * @param $id
     * @param $key
     *
     * @throws HttpException
     * @throws \yii\base\InvalidConfigException
     * @return \yii\web\Response
     */
    public function actionFlushCacheKey($id, $key)
    {
        if ($this->getCache($id)->delete($key)) {
            Yii::$app->session->setFlash('alert', [
                'body'    => \Yii::t('backend', 'Cache entry has been successfully deleted'),
                'options' => ['class' => 'alert-success'],
            ]);
        };

        return $this->redirect(['index']);
    }

    /**
     * @param $id
     * @param $tag
     *
     * @throws HttpException
     * @throws \yii\base\InvalidConfigException
     * @return \yii\web\Response
     */
    public function actionFlushCacheTag($id, $tag)
    {
        TagDependency::invalidate($this->getCache($id), $tag);
        Yii::$app->session->setFlash('alert', [
            'body'    => \Yii::t('backend', 'TagDependency was invalidated'),
            'options' => ['class' => 'alert-success'],
        ]);

        return $this->redirect(['index']);
    }

    /**
     * @param $id
     *
     * @throws HttpException
     * @throws \yii\base\InvalidConfigException
     * @return \yii\caching\Cache|null
     */
    protected function getCache($id)
    {
        if (!in_array($id, array_keys($this->findCaches()), true)) {
            throw new HttpException(400, 'Given cache name is not a name of cache component');
        }

        return Yii::$app->get($id);
    }

    /**
     * Returns array of caches in the system, keys are cache components names, values are class names.
     *
     * @param array $cachesNames caches to be found
     *
     * @return array
     */
    private function findCaches(array $cachesNames = [])
    {
        $caches = [];
        $components = Yii::$app->getComponents();
        $findAll = ($cachesNames === []);

        foreach ($components as $name => $component) {
            if (!$findAll && !in_array($name, $cachesNames, true)) {
                continue;
            }

            if ($component instanceof Cache) {
                $caches[$name] = ['name' => $name, 'class' => get_class($component)];
            } else if (is_array($component) && isset($component['class']) && $this->isCacheClass($component['class'])) {
                $caches[$name] = ['name' => $name, 'class' => $component['class']];
            } else if (is_string($component) && $this->isCacheClass($component)) {
                $caches[$name] = ['name' => $name, 'class' => $component];
            }
        }

        return $caches;
    }

    /**
     * Checks if given class is a Cache class.
     *
     * @param string $className class name.
     *
     * @return boolean
     */
    private function isCacheClass($className)
    {
        return is_subclass_of($className, Cache::class);
    }
}
