<?php

namespace core\modules\forum\models;

use core\modules\forum\models\db\PostThumbActiveRecord;

/**
 * PostThumb model
 */
class PostThumb extends PostThumbActiveRecord {}
