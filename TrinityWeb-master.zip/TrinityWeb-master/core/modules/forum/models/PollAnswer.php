<?php

namespace core\modules\forum\models;

use core\modules\forum\models\db\PollAnswerActiveRecord;

/**
 * Poll answer model
 * Forum polls.
 */
class PollAnswer extends PollAnswerActiveRecord {}
