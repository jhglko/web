<?php

namespace core\modules\forum\models;

use core\modules\forum\models\db\ModActiveRecord;

/**
 * Mod model
 * Forum moderators.
 */
class Mod extends ModActiveRecord {}
