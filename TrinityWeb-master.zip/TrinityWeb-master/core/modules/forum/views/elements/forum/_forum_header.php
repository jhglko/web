<tr class="d-flex">
    <td class="col-4 col-lg-6">
        <small><?php echo Yii::t('podium/view', 'Forum'); ?></small>
    </td>
    <td class="col-2 col-lg-1 text-right">
        <small><?php echo Yii::t('podium/view', 'Threads'); ?></small>
    </td>
    <td class="col-3 col-lg-2 text-right">
        <small><?php echo Yii::t('podium/view', 'Posts'); ?></small>
    </td>
    <td class="col-3">
        <small><?php echo Yii::t('podium/view', 'Latest Post'); ?></small>
    </td>
</tr>
