<?php

/**
 * Podium Module
 * Yii 2 Forum Module
 */

?>
<tr>
    <th class="col-sm-7"><small><?php echo Yii::t('podium/view', 'Thread'); ?></small></th>
    <th class="col-sm-1 text-center"><small><?php echo Yii::t('podium/view', 'Replies'); ?></small></th>
    <th class="col-sm-1 text-center"><small><?php echo Yii::t('podium/view', 'Views'); ?></small></th>
    <th class="col-sm-3"><small><?php echo Yii::t('podium/view', 'Post Author'); ?></small></th>
</tr>
