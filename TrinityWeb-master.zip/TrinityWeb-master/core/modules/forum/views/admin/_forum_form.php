<?php echo $form->field($node, 'category_id')->hiddenInput()->label(false);?>
<?php echo $form->field($node, 'sub');?>