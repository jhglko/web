<?php

/**
 * Podium Module
 * Yii 2 Forum Module
 */

use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;

$this->title = Yii::t('podium/view', 'Podium Settings');
$this->params['breadcrumbs'][] = ['label' => Yii::t('podium/view', 'Administration Dashboard'), 'url' => ['admin/index']];
$this->params['breadcrumbs'][] = $this->title;

?>
<?php echo $this->render('/elements/admin/_navbar', ['active' => 'settings']); ?>
<br>
<div class="row">
    <div class="col-md-3 col-sm-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title"><?php echo Yii::t('podium/view', 'Settings Index'); ?></h3>
            </div>
            <div class="list-group">
                <a href="#maintenance" class="list-group-item"><?php echo Yii::t('podium/view', 'Maintenance mode'); ?></a>
                <a href="#meta" class="list-group-item"><?php echo Yii::t('podium/view', 'Meta data'); ?></a>
                <a href="#posts" class="list-group-item"><?php echo Yii::t('podium/view', 'Posts'); ?></a>
                <a href="#guests" class="list-group-item"><?php echo Yii::t('podium/view', 'Guests privileges'); ?></a>
                <a href="#emails" class="list-group-item"><?php echo Yii::t('podium/view', 'E-mails'); ?></a>
                <a href="#db" class="list-group-item"><?php echo Yii::t('podium/view', 'Database'); ?></a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-sm-8">
        <div class="panel panel-default">
            <?php $form = ActiveForm::begin(['id' => 'settings-form']); ?>
                <div class="panel-heading">
                    <h3 class="panel-title"><?php echo Yii::t('podium/view', 'Podium Settings'); ?></h3>
                </div>
                <div class="panel-body">
                    <p><?php echo Yii::t('podium/view', 'Leave setting empty if you want to restore the default Podium value.'); ?></p>
                    <h3 id="maintenance"><span class="label label-primary"><?php echo Yii::t('podium/view', 'Maintenance mode'); ?></span></h3>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php
                            $field = $form->field($model, 'forum.maintenance_mode', ['options' => [
                                'class' => 'position-relative'
                            ]]);
                            $field->template = '{input} {label}';
                            echo $field->checkbox([], false)->label(Yii::t('podium/view', 'Set forum to Maintenance mode'),[
                                'class' => 'checkbox-label'
                            ])->hint(Yii::t('podium/view', 'All users without Administrator privileges will be redirected to {maintenancePage}.', ['maintenancePage' => Html::a(Yii::t('podium/view', 'Maintenance page'), ['forum/maintenance'])])); ?>
                        </div>
                    </div>
                    <h3 id="meta"><span class="label label-primary"><?php echo Yii::t('podium/view', 'Meta data'); ?></span></h3>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo $form->field($model, 'forum.name')->textInput()->label(Yii::t('podium/view', "Forum's Name")); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo $form->field($model, 'forum.meta_keywords')->textInput()->label(Yii::t('podium/view', 'Global meta keywords')); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo $form->field($model, 'forum.meta_description')->textInput()->label(Yii::t('podium/view', 'Global meta description')); ?>
                        </div>
                    </div>
                    <h3 id="posts"><span class="label label-primary"><?php echo Yii::t('podium/view', 'Posts'); ?></span></h3>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo $form->field($model, 'forum.hot_minimum')->textInput()->label(Yii::t('podium/view', 'Minimum number of posts for thread to become Hot')); ?>
                        </div>
                        <div class="col-sm-12">
                            <?php
                            $field = $form->field($model, 'forum.merge_posts', ['options' => [
                                'class' => 'position-relative'
                            ]]);
                            $field->template = '{input} {label}';
                            echo $field->checkbox([], false)->label(Yii::t('podium/view', 'Merge reply with post in case of the same author'),[
                                'class' => 'checkbox-label'
                            ]);
                            ?>
                        </div>
                        <div class="col-sm-12">
                            <?php
                            $field = $form->field($model, 'forum.allow_polls', ['options' => [
                                'class' => 'position-relative'
                            ]]);
                            $field->template = '{input} {label}';
                            echo $field->checkbox([], false)->label(Yii::t('podium/view', 'Allow polls adding'),[
                                'class' => 'checkbox-label'
                            ]);
                            ?>
                        </div>
                        <div class="col-sm-12">
                            <?php
                            $field = $form->field($model, 'forum.use_wysiwyg', ['options' => [
                                'class' => 'position-relative'
                            ]]);
                            $field->template = '{input} {label}';
                            echo $field->checkbox([], false)->label(Yii::t('podium/view', 'Use WYSIWYG editor'),[
                                'class' => 'checkbox-label'
                            ])->hint(Yii::t('podium/view', '{WYSIWYG} stands for What You See Is What You Get and Podium uses {Quill} for this way of posting. If you would like to switch it off {CodeMirror} in {Markdown} mode will be used instead.', [
                                'WYSIWYG'    => Html::a('WYSIWYG', 'https://en.wikipedia.org/wiki/WYSIWYG'),
                                'Quill'      => Html::a('Quill', 'https://quilljs.com'),
                                'CodeMirror' => Html::a('CodeMirror', 'https://codemirror.net'),
                                'Markdown'   => Html::a('Markdown', 'https://en.wikipedia.org/wiki/Markdown')
                            ]));?>
                        </div>
                    </div>
                    <h3 id="guests"><span class="label label-primary"><?php echo Yii::t('podium/view', 'Guests privileges'); ?></span></h3>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo $form->field($model, 'forum.members_visible')->checkBox()->label(Yii::t('podium/view', 'Allow guests to list members')); ?>
                        </div>
                    </div>
                    <h3 id="emails"><span class="label label-primary"><?php echo Yii::t('podium/view', 'E-mails'); ?></span></h3>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo $form->field($model, 'forum.max_attempts')->textInput()->label(Yii::t('podium/view', 'Maximum number of email sending attempts before giving up')); ?>
                        </div>
                    </div>
                    <h3 id="db"><span class="label label-primary"><?php echo Yii::t('podium/view', 'Database'); ?></span></h3>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo $form->field($model, 'forum.version')->textInput(['readonly' => true])->label(Yii::t('podium/view', 'Database version (read only)')); ?>
                        </div>
                    </div>
                </div>
                <div class="panel-footer">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo Html::submitButton('<span class="glyphicon glyphicon-ok-sign"></span> ' . Yii::t('podium/view', 'Save Settings'), ['class' => 'btn btn-block btn-primary', 'name' => 'save-button']); ?>
                        </div>
                    </div>
                </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
    <div class="col-md-3 col-sm-8 col-sm-offset-4 col-md-offset-0">
        <a href="<?php echo Url::to(['admin/clear']); ?>" class="btn btn-danger btn-block"><span class="glyphicon glyphicon-alert"></span> <?php echo Yii::t('podium/view', 'Clear all cache'); ?></a>
    </div>
</div><br>
