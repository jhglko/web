<?php declare(strict_types=1);

namespace core\models\query;

use omgdef\multilingual\MultilingualQuery;

/**
 * Class MetaQuery
 * @package core\models\query
 */
class MetaQuery extends MultilingualQuery
{
}