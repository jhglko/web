<?php

use yii\db\Migration;

/**
 * Class m180823_070939_file_storage_item
 */
class m180823_070939_file_storage_item extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        $this->createTable('{{%file_storage_item}}', [
            'id'         => $this->primaryKey(),
            'component'  => $this->string()->notNull(),
            'base_url'   => $this->string(1024)->notNull(),
            'path'       => $this->string(1024)->notNull(),
            'type'       => $this->string(),
            'size'       => $this->integer(),
            'name'       => $this->string(),
            'upload_ip'  => $this->string(15),
            'created_at' => $this->integer()->notNull()
        ], $tableOptions);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%file_storage_item}}');
    }
}
